const RAW=window.CHECKLIST_DATA;
const UNITS=['376/377','577','573','870'];
const GROUPS={'SL0':['Outgoing','Rigup','RigDown','Incoming'],'SL1/3/4':['SL1','SL3','SL4']};
const SLS=[...GROUPS.SL0,...GROUPS['SL1/3/4']];
const SLNAME=s=>GROUPS.SL0.includes(s)?'SL0 '+s:s;
const GOF=s=>GROUPS.SL0.includes(s)?'SL0':'SL1/3/4';
const sections=RAW.sections;
let seed=7;const rnd=()=>(seed=(seed*16807)%2147483647)/2147483647;
const checks=RAW.checks.map((c,i)=>({id:i,wr:'RC-'+(40210+i*7),...c,o:c.o.map(o=>({t:o[0],bad:!!o[1]})),swi:!!c.swi,rows:c.d.map(([u,s])=>({u,s,st:'synced'})),history:[{t:'2026-06-02',who:'Initial seed',what:'Imported from WorkRight'}]}));
const mismatches=[];
checks.forEach(c=>{const r=rnd();
 if(r<0.025){const row=c.rows[Math.floor(rnd()*c.rows.length)];row.st='drift';
  const opt=c.o.length&&rnd()<.6?Math.floor(rnd()*c.o.length):null;
  mismatches.push({id:mismatches.length,check:c.id,u:row.u,s:row.s,type:opt!==null?'Answer wording changed':'Missing from WorkRight checklist',opt,app:opt!==null?c.o[opt].t:'Present in CPF-'+row.u+' '+SLNAME(row.s),wr:opt!==null?c.o[opt].t.replace(/damage/i,'damages')+' (edited)':'Not found in last scrape',done:null});}
 else if(r<0.04){const row=c.rows[Math.floor(rnd()*c.rows.length)];row.st='pending';c.history.push({t:'2026-09-11',who:'A. Tan (TLM)',what:'Added to CPF-'+row.u+' '+SLNAME(row.s)});}
});
const status=c=>c.rows.some(r=>r.st==='drift')?'drift':c.rows.some(r=>r.st==='pending')?'pending':'synced';
const esc=s=>String(s).replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const att=s=>String(s).replace(/'/g,'&#39;').replace(/"/g,'&quot;');
const $=s=>document.querySelector(s);
const TODAY='2026-09-17',ME='You (TLM)';
let view='dash',mg='SL0',q='',fsec='',fst='';
let fu=[],fs=[],mode='any',onlyCols=true,openRow=null,editing=false,clickT=null;
const MODES={any:'In any selected unit',all:'Shared by all selected',only:'Only in selected units',missing:'Missing from selected'};
function toast(t){const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>e.style.display='none',2800)}
function counts(){let s=0,p=0,d=0;checks.forEach(c=>c.rows.forEach(r=>r.st==='synced'?s++:r.st==='pending'?p++:d++));return{s,p,d}}
function pendList(){const out=[];checks.forEach(c=>c.rows.forEach(r=>r.st==='pending'&&out.push({c,r})));return out}
function nav(){document.querySelectorAll('nav button').forEach(b=>b.toggleAttribute('aria-current',b.dataset.v===view));$('#rqc').textContent=mismatches.filter(m=>!m.done).length+pendList().length}
function go(v){view=v;render()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>go(b.dataset.v));
function render(){nav();({dash,matrix,add,review})[view]()}
function log(c,what){c.history.push({t:TODAY,who:ME,what})}
function sim(a,b){const t=s=>new Set(s.toLowerCase().match(/[a-z]{3,}/g)||[]);const A=t(a),B=t(b);let i=0;A.forEach(x=>B.has(x)&&i++);return i/(A.size+B.size-i||1)}

function dash(){const k=counts();
 const unitBars=UNITS.map(u=>{let a=[0,0,0];checks.forEach(c=>c.rows.forEach(r=>{if(r.u===u)a[r.st==='synced'?0:r.st==='pending'?1:2]++}));const t=a[0]+a[1]+a[2]||1;
  return `<div class="bar"><b>CPF-${u}</b><div class="track"><i style="width:${a[0]/t*100}%;background:var(--ok)"></i><i style="width:${Math.max(a[1]/t*100,a[1]?1.5:0)}%;background:var(--pend)"></i><i style="width:${Math.max(a[2]/t*100,a[2]?1.5:0)}%;background:var(--drift)"></i></div><span class="muted">${t}</span></div>`}).join('');
 const open=mismatches.filter(m=>!m.done).slice(0,5).map(m=>`<div class="log"><div><span class="pill drift">Drift</span> CPF-${m.u} ${SLNAME(m.s)} · <a href="#" onclick="openD(${m.check});return false">${esc(checks[m.check].n.slice(0,60))}…</a></div></div>`).join('')||'<p class="muted">No open drift.</p>';
 $('#main').innerHTML=`<h2>Checklist health</h2><p class="sub">Last WorkRight scrape ran Monday 14 Sep 2026, 06:00. ${checks.length} checks across 4 units and 28 documents.</p>
 <div class="stats"><div class="panel stat"><b>${checks.length}</b><span>Checks in master</span></div><div class="panel stat ok"><b>${k.s}</b><span>Document rows in sync</span></div><div class="panel stat pend"><b>${k.p}</b><span>Waiting for WorkRight entry</span></div><div class="panel stat drift"><b>${k.d}</b><span>Differ from WorkRight</span></div></div>
 <div class="grid2"><div class="panel"><h3>Sync by unit</h3>${unitBars}<div class="legend" style="margin-top:12px"><span><i class="dot synced"></i> Synced</span><span><i class="dot pending"></i> Pending</span><span><i class="dot drift"></i> Drift</span></div></div>
 <div class="panel"><h3>Needs attention</h3>${open}<p style="margin-top:12px"><button class="btn ghost" onclick="go('review')">Open review queue</button></p></div></div>`}

function chip(on,label,fn){return `<button class="chip" aria-pressed="${on}" onclick="${fn}">${label}</button>`}
function matrix(){const g=GROUPS[mg];fs=fs.filter(s=>g.includes(s));
 const {us,ss}=cols();
 const secOpts=[...new Set(checks.filter(c=>c.g===mg).map(c=>c.s))].map(s=>`<option value="${s}" ${fsec==s?'selected':''}>${esc(sections[s].name)}</option>`).join('');
 $('#main').innerHTML=`<h2>Matrix view</h2><p class="sub">Single click a check to see its answers, double click to open and edit it. Use + on a section to add a check there.</p>
 <div class="toolbar"><div class="seg" role="group" aria-label="Checklist"><button aria-pressed="${mg==='SL0'}" onclick="mg='SL0';fsec='';openRow=null;matrix()">SL0 checks</button><button aria-pressed="${mg!=='SL0'}" onclick="mg='SL1/3/4';fsec='';openRow=null;matrix()">SL1, 3 &amp; 4 tasks</button></div>
 <input type="search" placeholder="Search check wording" value="${att(q)}" oninput="q=this.value;drawRows()" aria-label="Search checks">
 <select onchange="fsec=this.value;drawRows()" aria-label="Section"><option value="">All sections</option>${secOpts}</select>
 <select onchange="fst=this.value;drawRows()" aria-label="Status"><option value="">All statuses</option><option value="pending" ${fst==='pending'?'selected':''}>Pending</option><option value="drift" ${fst==='drift'?'selected':''}>Drift</option></select></div>
 <div class="filters panel">
  <div class="frow"><span class="flabel">Units</span>${UNITS.map(u=>chip(fu.includes(u),'CPF-'+u,`tog('u','${u}')`)).join('')}
   <select onchange="mode=this.value;matrix()" aria-label="Unit match" ${fu.length?'':'disabled'}>${Object.entries(MODES).map(([k,v])=>`<option value="${k}" ${mode===k?'selected':''}>${v}</option>`).join('')}</select></div>
  <div class="frow"><span class="flabel">Service levels</span>${g.map(s=>chip(fs.includes(s),s,`tog('s','${s}')`)).join('')}
   <label class="tick"><input type="checkbox" ${onlyCols?'checked':''} onchange="onlyCols=this.checked;matrix()"> Show selected columns only</label>
   ${fu.length||fs.length?`<button class="linkbtn" onclick="fu=[];fs=[];mode='any';matrix()">Clear</button>`:''}<span style="margin-left:auto"><button class="btn ghost" onclick="expDlg()">Export PDF</button></span></div>
  <div class="fsum" id="cnt"></div>
 </div>
 <div class="mwrap"><table class="m"><thead><tr><th class="name" rowspan="2">Check</th><th rowspan="2" title="Units using this check at the selected levels">Units</th>${us.map(u=>`<th class="u" colspan="${ss.length}"><button class="hbtn" onclick="colFilter('${u}')" title="Show only CPF-${u}">CPF-${u}</button></th>`).join('')}</tr><tr>${us.map(u=>ss.map((s,i)=>`<th ${i===0?'class="u"':''}><button class="hbtn" onclick="colFilter('${u}','${s}')" title="Show only CPF-${u} ${SLNAME(s)}">${s}</button></th>`).join('')).join('')}</tr></thead><tbody id="rows"></tbody></table></div>`;
 drawRows()}
function colFilter(u,s){fu=[u];mode='any';onlyCols=true;fs=s?[s]:[];matrix()}
function tog(k,v){const a=k==='u'?fu:fs;const i=a.indexOf(v);i<0?a.push(v):a.splice(i,1);matrix()}
function cols(){return{us:onlyCols&&fu.length&&mode!=='missing'?UNITS.filter(u=>fu.includes(u)):UNITS,ss:onlyCols&&fs.length?GROUPS[mg].filter(s=>fs.includes(s)):GROUPS[mg]}}
function levels(){return fs.length?fs:GROUPS[mg]}
function has(c,u){const L=levels();return c.rows.some(r=>r.u===u&&L.includes(r.s))}
function baseMatch(c,g){const ql=q.toLowerCase();return c.g===g&&(!ql||c.n.toLowerCase().includes(ql))&&(g!==mg||fsec===''||c.s==fsec)&&(!fst||status(c)===fst)}
function unitMatch(c){const others=UNITS.filter(u=>!fu.includes(u));
 if(!fu.length)return UNITS.some(u=>has(c,u));
 if(mode==='any')return fu.some(u=>has(c,u));
 if(mode==='all')return fu.every(u=>has(c,u));
 if(mode==='only')return fu.every(u=>has(c,u))&&others.every(u=>!has(c,u));
 return fu.every(u=>!has(c,u))&&others.some(u=>has(c,u))}
function summary(n){if(!fu.length&&!fs.length)return `${n} checks`;
 const names=fu.map(u=>'CPF-'+u),lv=fs.length?' at '+fs.join(', '):'',join=a=>a.length>1?a.slice(0,-1).join(', ')+' and '+a.at(-1):a[0];
 if(!fu.length)return `<b>${n}</b> checks used by any unit${lv}`;
 return `<b>${n}</b> checks ${({any:'in '+join(names).replace(' and ',' or '),all:(fu.length>1?'shared by ':'in ')+join(names),only:'used only by '+join(names),missing:'used elsewhere but missing from '+join(names)})[mode]}${lv}`}
function ansRow(c){if(!c.o.length)return `<div class="muted">No answer options in the source for this task. ${c.g==='SL0'?'':'SL1, 3 and 4 tasks have none in the ACP export.'}</div>`;
 return `<div class="answers">${c.o.map(o=>`<span class="ans ${o.bad?'bad':'good'}"><i></i>${esc(o.t)}</span>`).join('')}</div>`}
function drawRows(){const {us,ss}=cols();let last=-1,n=0,h='';const span=2+us.length*ss.length;
 checks.filter(c=>baseMatch(c,mg)&&unitMatch(c)).forEach(c=>{n++;
  if(c.s!==last){last=c.s;const s=sections[c.s];h+=`<tr class="sec"><td colspan="${span}"><span>${esc(s.name)}${s.wo&&s.wo!=='SL0'?' <span class="muted" style="font-weight:500">· '+esc(s.wo)+'</span>':''}</span><button class="addbtn" onclick="newCheck(${c.s})" title="Add a check to ${att(s.name)}" aria-label="Add a check to ${att(s.name)}">+</button></td></tr>`}
  const k=UNITS.filter(u=>has(c,u)).length,op=openRow===c.id;
  h+=`<tr class="row${op?' on':''}" tabindex="0" aria-expanded="${op}" onclick="rowClick(${c.id})" ondblclick="rowDbl(${c.id})" onkeydown="rowKey(event,${c.id})"><td class="name"><span class="nm"><span class="caret">${op?'&#9662;':'&#9656;'}</span><span class="clamp">${esc(c.n)}</span></span></td><td><span class="ucount ${k===4?'full':''}">${k}/4</span></td>${us.map(u=>ss.map((s,i)=>{const r=c.rows.find(r=>r.u===u&&r.s===s);return `<td ${i===0?'class="gl"':''}><i class="dot ${r?r.st:'none'}" title="CPF-${u} ${SLNAME(s)}: ${r?r.st:'not in document'}"></i></td>`}).join('')).join('')}</tr>`;
  if(op)h+=`<tr class="det"><td colspan="${span}"><div class="detin"><b>Answers</b>${ansRow(c)}<div class="detfoot"><span class="muted">${c.rows.length} document${c.rows.length>1?'s':''} · ${c.swi?'SWI needed':'no SWI'}</span><button class="btn ghost sm" onclick="event.stopPropagation();openD(${c.id},true)">Open and edit</button></div></div></td></tr>`});
 $('#rows').innerHTML=h||`<tr><td colspan="99" style="padding:30px" class="muted">No checks match. Change the unit mode or clear the filters.</td></tr>`;$('#cnt').innerHTML=summary(n)}
function rowClick(id){clearTimeout(clickT);clickT=setTimeout(()=>{openRow=openRow===id?null:id;drawRows()},200)}
function rowDbl(id){clearTimeout(clickT);openD(id,true)}
function rowKey(e,id){if(e.key==='Enter'){e.preventDefault();openD(id,true)}else if(e.key===' '){e.preventDefault();rowClick(id);clearTimeout(clickT);openRow=openRow===id?null:id;drawRows()}}

function openD(id,edit){const c=checks[id];editing=!!edit&&true;drawD(id)}
function drawD(id){const c=checks[id],st=status(c),sl=GROUPS[c.g],s=sections[c.s];
 const grid=`<table class="use"><thead><tr><th></th>${sl.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${UNITS.map(u=>`<tr><td>CPF-${u}</td>${sl.map(x=>{const r=c.rows.find(r=>r.u===u&&r.s===x);
  return `<td><button class="tick2 ${r?r.st:'off'}" onclick="toggleUse(${id},'${u}','${x}')" aria-pressed="${!!r}" title="${r?'In CPF-'+u+' '+SLNAME(x)+' ('+r.st+') — click to remove':'Not used — click to add'}"></button></td>`}).join('')}</tr>`).join('')}</tbody></table>`;
 const have=UNITS.filter(u=>c.rows.some(r=>r.u===u)),missing=UNITS.filter(u=>!have.includes(u));
 const impact=`<p>Changing this check touches <b>${c.rows.length} document${c.rows.length!==1?'s':''}</b> across <b>${have.length} unit${have.length!==1?'s':''}</b>.</p><ul class="impact">${have.map(u=>`<li>CPF-${u}: ${c.rows.filter(r=>r.u===u).map(r=>SLNAME(r.s)).sort().join(', ')}</li>`).join('')}</ul>${missing.length?`<p class="muted">Not used by ${missing.map(u=>'CPF-'+u).join(', ')}. Check whether that is intended.</p>`:''}`;
 const looks=checks.filter(x=>x.id!==id&&x.g===c.g).map(x=>[x,sim(c.n,x.n)]).filter(a=>a[1]>.55).sort((a,b)=>b[1]-a[1]).slice(0,3);
 const optsView=c.o.length?`<table class="opt"><tbody>${c.o.map((o,i)=>{const mm=mismatches.find(m=>m.check===id&&m.opt===i&&!m.done);return `<tr><td style="width:24px">${i+1}</td><td><span class="ans ${o.bad?'bad':'good'}"><i></i>${esc(o.t)}</span> ${mm?'<span class="pill drift">Drift</span>':''}</td><td style="width:70px;text-align:right" class="muted">${o.bad?'Defect':'Good'}</td></tr>`}).join('')}</tbody></table>`:`<p class="muted">No answer options in the source${c.g==='SL0'?'':' — the ACP export has none for SL1, 3 and 4 tasks'}.</p>`;
 const optsEdit=`<div id="oed">${c.o.map((o,i)=>optRow(o,i)).join('')}</div><button class="btn ghost sm" onclick="addOpt()">Add answer</button>`;
 const head=editing?`<div class="panel"><span class="pill ${st}">${st[0].toUpperCase()+st.slice(1)}</span>
  <label class="fld"><span>Check wording</span><textarea id="ed_n" rows="3">${esc(c.n)}</textarea></label>
  <label class="fld"><span>Comments</span><input type="text" id="ed_c" value="${att(c.c||'')}"></label>
  <label class="tick"><input type="checkbox" id="ed_swi" ${c.swi?'checked':''}> SWI needed</label>
  <div class="meta"><span>${esc(s.name)}</span>${s.wo&&s.wo!=='SL0'?`<span>${esc(s.wo)}</span>`:''}<span>WorkRight ${esc(c.wr)}</span></div>
  <div class="frow" style="margin-top:12px"><button class="btn" onclick="saveEdit(${id})">Save changes</button><button class="btn ghost" onclick="editing=false;drawD(${id})">Cancel</button><span class="muted" style="font-size:13px">Saved edits become pending until the scrape finds them in WorkRight.</span></div></div>`
 :`<div class="panel"><span class="pill ${st}">${st[0].toUpperCase()+st.slice(1)}</span><button class="btn ghost sm" style="float:right" onclick="editing=true;drawD(${id})">Edit</button>
  <h3 style="margin:10px 0 0;font-size:22px">${esc(c.n)}</h3>
  <div class="meta"><span>${esc(s.name)}</span>${s.wo&&s.wo!=='SL0'?`<span>${esc(s.wo)}</span>`:''}<span>WorkRight ${esc(c.wr)}</span><span>SWI ${c.swi?'needed':'not needed'}</span></div>${c.c?`<p class="muted" style="margin:8px 0 0;font-size:14px">${esc(c.c)}</p>`:''}</div>`;
 $('#drawer').innerHTML=`<button class="x" onclick="closeD()" aria-label="Close">×</button>${head}
 <details class="panel" open><summary><h3>Answers</h3></summary>${editing?optsEdit:optsView}</details>
 <div class="panel"><h3>Where it's used</h3>${grid}<p class="muted" style="font-size:13px;margin:8px 0 0">Click a box to tick or untick. Ticking adds the check to that document as pending; unticking removes it.</p></div>
 <details class="panel" open><summary><h3>Impact</h3></summary>${impact}</details>
 ${looks.length?`<details class="panel"><summary><h3>Look-alike checks (${looks.length})</h3></summary>${looks.map(([x,v])=>`<div class="log"><div><a href="#" onclick="openD(${x.id});return false">${esc(x.n)}</a> <span class="muted">${Math.round(v*100)}% word overlap</span></div></div>`).join('')}</details>`:''}
 <details class="panel"><summary><h3>History (${c.history.length})</h3></summary><div class="log">${c.history.slice().reverse().map(h=>`<div><b>${h.t}</b> · ${esc(h.who)} · ${esc(h.what)}</div>`).join('')}</div></details>`;
 $('#dr').className='open';$('#drawer').scrollTop=0;
 if(editing&&$('#ed_n'))$('#ed_n').focus();else $('#drawer .x').focus();
 window._cur=id}
function optRow(o,i){return `<div class="oline"><input type="text" value="${att(o.t)}" aria-label="Answer ${i+1}">
 <div class="seg sm" role="group" aria-label="Answer type"><button type="button" aria-pressed="${!o.bad}" onclick="setGB(this,0)">Good</button><button type="button" aria-pressed="${!!o.bad}" onclick="setGB(this,1)">Defect</button></div>
 <button class="del" type="button" onclick="this.parentNode.remove()" aria-label="Remove answer">×</button></div>`}
function setGB(b,bad){const seg=b.parentNode;seg.children[0].setAttribute('aria-pressed',!bad);seg.children[1].setAttribute('aria-pressed',!!bad)}
function addOpt(){$('#oed').insertAdjacentHTML('beforeend',optRow({t:'',bad:true},$('#oed').children.length));$('#oed').lastElementChild.querySelector('input').focus()}
function readOpts(){return [...document.querySelectorAll('#oed .oline')].map(l=>({t:l.querySelector('input').value.trim(),bad:l.querySelector('.seg button:last-child').getAttribute('aria-pressed')==='true'})).filter(o=>o.t)}
function saveEdit(id){const c=checks[id],n=$('#ed_n').value.trim();
 if(!n){toast('Check wording cannot be empty.');$('#ed_n').focus();return}
 const changes=[];
 if(n!==c.n){changes.push('wording');c.n=n}
 const cm=$('#ed_c').value.trim();if(cm!==(c.c||'')){changes.push('comments');c.c=cm}
 const sw=$('#ed_swi').checked;if(sw!==c.swi){changes.push('SWI flag');c.swi=sw}
 const no=readOpts();if(JSON.stringify(no)!==JSON.stringify(c.o.map(o=>({t:o.t,bad:o.bad})))){changes.push('answers');c.o=no}
 if(!changes.length){editing=false;drawD(id);toast('No changes to save.');return}
 c.rows.forEach(r=>{if(r.st==='synced')r.st='pending'});
 log(c,'Edited '+changes.join(', ')+' — now pending in WorkRight');
 editing=false;drawD(id);render();toast('Saved. '+c.rows.length+' document row'+(c.rows.length>1?'s':'')+' now pending WorkRight entry.')}
function toggleUse(id,u,s){const c=checks[id],i=c.rows.findIndex(r=>r.u===u&&r.s===s);
 if(i<0){c.rows.push({u,s,st:'pending'});log(c,`Added to CPF-${u} ${SLNAME(s)}`);toast(`Added to CPF-${u} ${SLNAME(s)}. Enter it in WorkRight to sync.`)}
 else{if(c.rows.length===1){toast('A check must stay in at least one document. Delete the check instead.');return}
  c.rows.splice(i,1);log(c,`Removed from CPF-${u} ${SLNAME(s)}`);toast(`Removed from CPF-${u} ${SLNAME(s)}. Remove it in WorkRight too.`)}
 drawD(id);if(view==='matrix')drawRows();else render()}
function closeD(){$('#dr').className='';editing=false}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if($('#modal').className==='open')closeM();else closeD()}});

function openM(title,body,wide){$('#modal').className='open';$('#mbox').className='mbox'+(wide?' wide':'');$('#mbox').innerHTML=`<button class="x" onclick="closeM()" aria-label="Close">×</button><h3 style="font-size:20px;margin:0 0 12px">${title}</h3>${body}`}
function closeM(){$('#modal').className=''}
function newCheck(secId){const s=sections[secId],g=s.wo==='SL0'?'SL0':'SL1/3/4',L=GROUPS[g];
 openM(`Add a check to ${esc(s.name)}`,`<div class="form">
 <label class="fld"><span>Check wording</span><textarea id="nc_n" rows="3" oninput="ncDup()" placeholder="e.g. Suction hose and fittings"></textarea><span class="err" id="nc_ne"></span></label>
 <div id="nc_dup"></div>
 ${g==='SL0'?`<div><b>Answers</b><div id="oed">${[{t:'Good condition',bad:false},{t:'Damaged',bad:true},{t:'Other defect—add deficiency note or photo, or both',bad:true}].map((o,i)=>optRow(o,i)).join('')}</div><button class="btn ghost sm" type="button" onclick="addOpt()">Add answer</button></div>`:'<div id="oed" hidden></div>'}
 <div><b>Put it in these documents</b><div style="overflow:auto"><table class="assign" id="nc_a"><tr><th></th>${L.map(x=>`<th>${x}</th>`).join('')}</tr>${UNITS.map(u=>`<tr><td>CPF-${u}</td>${L.map(x=>`<td><input type="checkbox" data-u="${u}" data-s="${x}" aria-label="CPF-${u} ${SLNAME(x)}"></td>`).join('')}</tr>`).join('')}</table></div><span class="err" id="nc_ae"></span></div>
 <label class="tick"><input type="checkbox" id="nc_swi"> SWI needed</label>
 <div class="frow"><button class="btn" onclick="saveNew(${secId})">Add check</button><button class="btn ghost" onclick="closeM()">Cancel</button></div></div>`,true);
 $('#nc_n').focus()}
function ncDup(){const v=$('#nc_n').value.trim();$('#nc_ne').textContent='';
 if(v.length<10){$('#nc_dup').innerHTML='';return}
 const hits=checks.map(c=>[c,sim(v,c.n)]).filter(a=>a[1]>.5).sort((a,b)=>b[1]-a[1]).slice(0,3);
 $('#nc_dup').innerHTML=hits.length?`<div class="warn"><b>Similar checks already exist.</b> Adding one of these to more documents may be better than creating a new check.${hits.map(([c,s])=>`<div style="margin-top:4px"><a href="#" onclick="closeM();openD(${c.id});return false">${esc(c.n)}</a> <span class="muted">${Math.round(s*100)}% overlap · ${c.rows.length} documents</span></div>`).join('')}</div>`:''}
function saveNew(secId){const n=$('#nc_n').value.trim(),boxes=[...document.querySelectorAll('#nc_a input:checked')].map(b=>({u:b.dataset.u,s:b.dataset.s})),o=readOpts(),swi=$('#nc_swi').checked;
 let ok=true;
 if(!n){$('#nc_ne').textContent='Enter the check wording first.';ok=false}
 if(!boxes.length){$('#nc_ae').textContent='Pick at least one document.';ok=false}
 if(!ok)return;
 const dupe=checks.map(c=>[c,sim(n,c.n)]).filter(a=>a[1]>.5).sort((a,b)=>b[1]-a[1])[0];
 if(dupe){window._pend={secId,n,boxes,o,swi};
  const [c,s]=dupe,exact=c.n.trim().toLowerCase()===n.toLowerCase();
  openM('This check may already exist',`<p>${exact?'A check with this exact wording is already in the master:':`A ${Math.round(s*100)}% similar check is already in the master:`}</p>
  <div class="warn"><b>${esc(c.n)}</b><div class="muted" style="margin-top:4px">${esc(sections[c.s].name)} &middot; in ${c.rows.map(r=>'CPF-'+r.u+' '+SLNAME(r.s)).slice(0,4).join(', ')}${c.rows.length>4?' +'+(c.rows.length-4)+' more':''}</div></div>
  <p>Adding a duplicate makes the two drift apart in WorkRight. Add the existing check to more documents instead?</p>
  <div class="frow"><button class="btn" onclick="closeM();openD(${c.id})">Open the existing check</button><button class="btn ghost" onclick="reNew()">Add mine anyway</button><button class="btn ghost" onclick="newCheck(${secId})">Back to the form</button></div>`,true);return}
 commitNew(secId,n,boxes,o,swi)}
function reNew(){const p=window._pend;closeM();commitNew(p.secId,p.n,p.boxes,p.o,p.swi)}
function commitNew(secId,n,boxes,o,swi){
 const g=sections[secId].wo==='SL0'?'SL0':'SL1/3/4';
 const c={id:checks.length,wr:'Not in WorkRight yet',s:secId,n,o,swi,c:'',g,d:[],rows:boxes.map(b=>({u:b.u,s:b.s,st:'pending'})),history:[{t:TODAY,who:ME,what:`Created in ${boxes.length} document${boxes.length>1?'s':''}`}]};
 checks.push(c);closeM();mg=g;fsec='';toast(`Added as pending in ${boxes.length} document${boxes.length>1?'s':''}. Enter it in WorkRight to sync.`);render();openD(c.id)}

let expU=null,expL=null,expGrp='unit',expAns=true;
function expDlg(){if(!expU)expU=fu.length?[...fu]:[...UNITS];
 if(!expL)expL=fs.length?[...fs]:[...GROUPS[mg]];
 const box=(a,v,lab)=>`<label class="tick"><input type="checkbox" ${a.includes(v)?'checked':''} onchange="expTog('${a===expU?'u':'l'}','${v}')"> ${lab}</label>`;
 const docsN=expU.length*expL.length;
 openM('Export PDF',`<div class="form">
 <div><b>Units</b><div class="frow">${UNITS.map(u=>box(expU,u,'CPF-'+u)).join('')}</div></div>
 <div><b>Service levels</b><div class="frow">${GROUPS.SL0.map(s=>box(expL,s,'SL0 '+s)).join('')}</div><div class="frow">${GROUPS['SL1/3/4'].map(s=>box(expL,s,s)).join('')}</div></div>
 <div class="frow"><span class="flabel">Order by</span><div class="seg" role="group" aria-label="Order"><button aria-pressed="${expGrp==='unit'}" onclick="expGrp='unit';expDlg()">Unit, then level</button><button aria-pressed="${expGrp==='level'}" onclick="expGrp='level';expDlg()">Level, then unit</button></div></div>
 <label class="tick"><input type="checkbox" ${expAns?'checked':''} onchange="expAns=this.checked"> Include answers</label>
 <p class="muted" style="margin:0;font-size:14px">${docsN?`${docsN} document${docsN>1?'s':''}, one per page. The search, section and status filters in the matrix still apply.`:'Pick at least one unit and one service level.'}</p>
 <div class="frow"><button class="btn" id="expbtn" onclick="exportPdf()" ${docsN?'':'disabled'}>Create PDF</button><button class="btn ghost" onclick="closeM()">Cancel</button><span class="err" id="experr"></span></div></div>`,true)}
function expTog(k,v){const a=k==='u'?expU:expL,i=a.indexOf(v);i<0?a.push(v):a.splice(i,1);expDlg()}
let dlP=null;function getDL(){if(!dlP)dlP=(window.claude&&window.claude.use)?window.claude.use('downloads').catch(()=>null):Promise.resolve(null);return dlP}
const pdfSafe=s=>String(s).replace(/[→]/g,'->').replace(/[—–]/g,'-').replace(/[^\x09\x0A\x0D\x20-\xFF]/g,'');
async function exportPdf(){const b=$('#expbtn'),e=$('#experr');e.textContent='';
 if(!window.jspdf){e.textContent='The PDF library did not load. Reload the page.';return}
 const dl=await getDL();b.disabled=true;b.textContent='Building…';
 try{const {jsPDF}=window.jspdf,doc=new jsPDF({orientation:'landscape',unit:'pt',format:'a4'});
  const us=UNITS.filter(u=>expU.includes(u)),ls=SLS.filter(s=>expL.includes(s));
  const pairs=[];
  if(expGrp==='unit')us.forEach(u=>ls.forEach(s=>pairs.push([u,s])));else ls.forEach(s=>us.forEach(u=>pairs.push([u,s])));
  let first=true;
  pairs.forEach(([u,s])=>{const g=GOF(s),list=checks.filter(c=>c.g===g&&baseMatch2(c,g)&&c.rows.some(r=>r.u===u&&r.s===s));
   if(!first)doc.addPage();first=false;
   doc.setFont('helvetica','bold');doc.setFontSize(15);doc.text(`CPF-${u} · ${SLNAME(s)} checklist`,36,40);
   doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(90);
   doc.text(pdfSafe(`${list.length} checks${fsec!==''?' · section: '+sections[fsec].name:''}${q?' · search: "'+q+'"':''}${fst?' · status: '+fst:''} · generated ${TODAY}`),36,56);doc.setTextColor(0);
   const headRow=expAns?['#','Check','Answers','SWI']:['#','Check','SWI'],n=headRow.length,body=[];let last=-1,i=0;
   list.forEach(c=>{if(c.s!==last){last=c.s;const sc=sections[c.s];body.push([{content:pdfSafe(sc.name+(g!=='SL0'&&sc.wo?'  ('+sc.wo+')':'')),colSpan:n,styles:{fillColor:[220,232,245],fontStyle:'bold'}}])}
    const row=[++i,pdfSafe(c.n)];
    if(expAns){const ans=c.o.length?pdfSafe(c.o.map((o,k)=>`${k+1}. ${o.t}  [${o.bad?'defect':'good'}]`).join('\n')):'No answer options in source';
     row.push(c.o.length?ans:{content:ans,styles:{textColor:[150,150,150],fontStyle:'italic'}})}
    row.push(c.swi?'Yes':'');body.push(row)});
   if(!list.length)body.push([{content:`No checks in CPF-${u} ${SLNAME(s)} match the current filters.`,colSpan:n}]);
   doc.autoTable({head:[headRow],body,startY:68,margin:{left:36,right:36,top:40,bottom:36},styles:{font:'helvetica',fontSize:8,cellPadding:3,valign:'top',lineColor:[211,218,224],lineWidth:.4},headStyles:{fillColor:[22,37,46],textColor:255},
    columnStyles:expAns?{0:{cellWidth:24},1:{cellWidth:300},3:{cellWidth:30}}:{0:{cellWidth:24},2:{cellWidth:36}},rowPageBreak:'avoid'})});
  const pages=doc.getNumberOfPages();for(let p=1;p<=pages;p++){doc.setPage(p);doc.setFontSize(8);doc.setTextColor(120);doc.text(`Page ${p} of ${pages}`,doc.internal.pageSize.getWidth()-36,doc.internal.pageSize.getHeight()-18,{align:'right'})}
  const fn=(us.length===1?`CPF-${us[0]}`:`CPF ${us.length} units`)+' '+(ls.length<=3?ls.map(SLNAME).join(' '):`${ls.length} levels`)+' checklist.pdf';
  if(dl)await dl.save({filename:fn,data:doc.output('blob')});else doc.save(fn);
  closeM();toast(`PDF saved · ${pairs.length} document${pairs.length>1?'s':''}.`)}
 catch(err){if(err&&err.code==='declined'){}else if(err&&err.code==='rate_limited')e.textContent='A save prompt is already open.';else e.textContent='Could not create the PDF'+(err&&err.code?` (${err.code}).`:'.');
  if($('#expbtn')){b.disabled=false;b.textContent='Create PDF'}}}
function baseMatch2(c,g){const ql=q.toLowerCase();return (!ql||c.n.toLowerCase().includes(ql))&&(g!==mg||fsec===''||c.s==fsec)&&(!fst||status(c)===fst)}

function review(){const open=mismatches.filter(m=>!m.done),pend=pendList(),closed=mismatches.filter(m=>m.done);
 $('#main').innerHTML=`<h2>Review queue</h2><p class="sub">Drift is where WorkRight no longer matches the master. Pending items were added or edited here and still need entering in WorkRight. Any TLM user can resolve these.</p>
 <div class="panel" style="margin-bottom:16px"><h3>Drift from last scrape (${open.length})</h3>${open.map(m=>{const c=checks[m.check];return `<div class="rq"><span class="pill drift">Drift</span><div><a href="#" onclick="openD(${c.id});return false"><b>${esc(c.n)}</b></a><div class="muted" style="font-size:14px">CPF-${m.u} ${SLNAME(m.s)} · ${m.type}${m.opt!==null?' · answer '+(m.opt+1):''}</div><div class="diff"><em>Master</em><span>${esc(m.app)}</span><em>WorkRight</em><span>${esc(m.wr)}</span></div></div><div style="display:grid;gap:6px"><button class="btn" onclick="resolve(${m.id},'Keep master, fix WorkRight')">Keep master</button><button class="btn ghost" onclick="resolve(${m.id},'Marked as fixed in WorkRight')">Fixed in WorkRight</button></div></div>`}).join('')||'<p class="muted">No open drift.</p>'}</div>
 <div class="panel" style="margin-bottom:16px"><h3>Waiting for WorkRight entry (${pend.length})</h3>${pend.slice(0,60).map(({c,r})=>`<div class="rq"><span class="pill pending">Pending</span><div><a href="#" onclick="openD(${c.id});return false"><b>${esc(c.n)}</b></a><div class="muted" style="font-size:14px">CPF-${r.u} ${SLNAME(r.s)}</div></div><button class="btn ghost" onclick="simSync(${c.id},'${r.u}','${r.s}')" title="Demo only: pretend the weekly scrape found it">Simulate scrape</button></div>`).join('')||'<p class="muted">Nothing waiting.</p>'}${pend.length>60?`<p class="muted" style="margin-top:10px">+${pend.length-60} more.</p>`:''}</div>
 ${closed.length?`<div class="panel"><h3>Resolved</h3><div class="log">${closed.map(m=>`<div>${esc(checks[m.check].n.slice(0,70))}… · CPF-${m.u} ${SLNAME(m.s)} · ${esc(m.done)}</div>`).join('')}</div></div>`:''}`}
function resolve(id,how){const m=mismatches[id];m.done=how+' · '+ME+', 17 Sep';const c=checks[m.check],r=c.rows.find(r=>r.u===m.u&&r.s===m.s);
 if(r)r.st=how.startsWith('Keep')?'pending':'synced';log(c,'Resolved drift: '+how);
 toast(how.startsWith('Keep')?'Kept master. Pending until WorkRight is fixed.':'Marked as synced.');render()}
function simSync(id,u,s){const c=checks[id],r=c.rows.find(r=>r.u===u&&r.s===s);if(r)r.st='synced';
 c.history.push({t:'2026-09-21',who:'Weekly scrape',what:`Found in CPF-${u} ${SLNAME(s)}, now synced`});toast('Scrape found it. Status is now synced.');render()}

let addType='check';
function add(){$('#main').innerHTML=`<h2>Add new</h2><p class="sub">New items are saved as pending. The weekly scrape marks them synced once they appear in WorkRight.</p>
 <div class="toolbar"><div class="seg" role="group" aria-label="What to add">${['check','unit','service level'].map(t=>`<button aria-pressed="${addType===t}" onclick="addType='${t}';add()">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div></div><div class="panel" id="af"></div>`;
 if(addType==='check'){$('#af').innerHTML=`<div class="form"><label class="fld"><span>Which section?</span><select id="pk_g" onchange="pkSec()"><option value="SL0">SL0 check</option><option value="SL1/3/4">SL1, 3 &amp; 4 task</option></select></label>
  <label class="fld"><span>Section</span><select id="pk_s"></select></label>
  <div><button class="btn" onclick="newCheck(+$('#pk_s').value)">Continue</button></div>
  <p class="muted" style="margin:0;font-size:14px">You can also add a check straight from the matrix: use the + on any section heading.</p></div>`;pkSec()}
 else{const isU=addType==='unit';$('#af').innerHTML=`<div class="form"><label class="fld"><span>${isU?'Unit name':'Service level name'}</span><input type="text" id="nn" placeholder="${isU?'e.g. CPF-880':'e.g. SL2 (375 hours)'}"><span class="err" id="nne"></span></label>
 ${isU?`<label class="fld"><span>Copy checks from</span><select id="cp"><option value="">Start empty</option>${UNITS.map(u=>`<option>CPF-${u}</option>`).join('')}</select></label><p class="muted" style="margin:0;font-size:14px">Copying creates pending rows for every check the source unit uses, so you can review before entering them in WorkRight.</p>`:`<label class="fld"><span>Belongs to</span><select><option>New group</option><option>SL0</option></select></label><label class="fld"><span>Interval</span><input type="text" placeholder="e.g. 375 hours"></label>`}
 <div><button class="btn" onclick="saveSimple()">Add ${addType}</button></div></div>`}}
function pkSec(){const g=$('#pk_g').value;$('#pk_s').innerHTML=[...new Set(checks.filter(c=>c.g===g).map(c=>c.s))].map(s=>`<option value="${s}">${esc(sections[s].name)}</option>`).join('')}
function saveSimple(){const v=$('#nn').value.trim();if(!v){$('#nne').textContent='Enter a name first.';return}toast(`${v} added. In the full app it appears as a new column in the matrix.`);$('#nn').value=''}
render();
