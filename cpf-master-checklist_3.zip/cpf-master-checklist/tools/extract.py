"""Rebuild data.js from the InTouch ACP master checklist workbook.

Usage:  python tools/extract.py "CPF Master Checklist - from InTouch ACP_18.xlsx"

Reads the SL0 and "SL1, 3 & 4" sheets, flattens each task into one record with
the documents it belongs to, and writes window.CHECKLIST_DATA into data.js.
Re-run this whenever a new ACP revision lands. Nothing else reads the workbook.
"""
import re,json,sys,os
from openpyxl import load_workbook
SRC=sys.argv[1] if len(sys.argv)>1 else 'CPF Master Checklist - from InTouch ACP_18.xlsx'
OUT=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'data.js')
wb=load_workbook(SRC,read_only=True)
U={'376/377','577','573','870'}
SLM={'outgoing':'Outgoing','rigup':'Rigup','rigdown':'RigDown','incoming':'Incoming','sl1':'SL1','sl3':'SL3','sl4':'SL4'}
JUNK=re.compile(r'SLB-P|\|\|\||V\d\.\d,\s*\d||Asset Care|^\s*Corrected\s*$|^\s*Maintenance',re.I)
def clean(s):
    if s is None: return ''
    s=re.sub(r'\s{3,}\d+\s*$','',str(s))
    return re.sub(r'\s+',' ',s).strip()
def docs(s):
    out=[]
    for part in str(s or '').split('|'):
        if ':' not in part: continue
        u,sls=part.split(':',1); u=u.strip()
        if u not in U: continue
        for t in sls.split(','):
            k=SLM.get(t.strip().lower())
            if k and [u,k] not in out: out.append([u,k])
    return out
checks=[];sections=[];junk=0;dedup=0
def sec(name,wo):
    sections.append({'id':len(sections),'name':name,'wo':wo}); return len(sections)-1
def addopts(raw):
    global junk,dedup
    out=[];seen=set()
    for t,bad in raw:
        t=clean(t)
        if not t: continue
        if JUNK.search(t): junk+=1; continue
        k=t.lower()
        if k in seen: dedup+=1; continue
        seen.add(k); out.append([t,1 if bad else 0])
    return out
cur=None
for r in list(wb['SL0'].iter_rows(values_only=True))[4:]:
    r=list(r)+[None]*31
    if r[2]=='HEADING': cur=sec(clean(r[1]),'SL0'); continue
    if not r[1] or not r[27]: continue
    d=docs(r[27])
    if not d: continue
    raw=[(r[2+3*i],r[3+3*i]=='YES') for i in range(5)]
    if r[28]: raw.append((r[28],'defect' in str(r[28]).lower()))
    checks.append({'s':cur,'n':clean(r[1]),'o':addopts(raw),'swi':1 if r[21]=='YES' else 0,'c':clean(r[26]),'d':d,'g':'SL0'})
cur=None;wo=''
for r in list(wb['SL1, 3 & 4'].iter_rows(values_only=True))[4:]:
    r=list(r)+[None]*15
    if r[0] and str(r[0]).startswith('WO'): wo=str(r[0]).strip(); continue
    if r[2]=='HEADING': cur=sec(clean(r[1]),wo); continue
    if not r[1] or not r[12]: continue
    d=docs(r[12])
    if not d: continue
    checks.append({'s':cur,'n':clean(r[1]),'o':[],'swi':1 if r[10]=='YES' else 0,'c':clean(r[11]),'d':d,'g':'SL1/3/4'})
with open(OUT,'w') as f:
    f.write('window.CHECKLIST_DATA=')
    json.dump({'checks':checks,'sections':sections},f,separators=(',',':'))
    f.write(';\n')
print(f'{len(checks)} checks, {len(sections)} sections -> {OUT}')
print(f'dropped {junk} junk options (footer text bleeding out of the Options 6+ column)')
print(f'dropped {dedup} duplicate answers within a check')
