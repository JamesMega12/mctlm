// End-to-end smoke test. Start the server first (node server.js), then:
//   npm i playwright && node tests/smoke.mjs
// Every assertion maps to a feature TLM asked for; add a case when you add a feature.
import {chromium} from 'playwright';
const URL=process.env.URL||'http://localhost:3000';
let fails=0;
const ok=(name,cond,got)=>{if(!cond)fails++;console.log(`${cond?'PASS':'FAIL'}  ${name}${cond?'':'  got: '+got}`)};
// CHROME_PATH lets you point at an existing Chromium instead of Playwright's download.
const b=await chromium.launch(process.env.CHROME_PATH?{executablePath:process.env.CHROME_PATH}:{});
const p=await b.newPage({viewport:{width:1400,height:900}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto(URL,{waitUntil:'networkidle'});

await p.click('nav button[data-v=matrix]');await p.waitForSelector('tr.row');
ok('SL0 matrix lists 183 checks',await p.locator('tr.row').count()===183,await p.locator('tr.row').count());

// Steps 1-4 use row 0; the duplicate test below needs row 1's wording left untouched.
// 1. single click expands answers
await p.locator('tr.row').nth(0).click();await p.waitForTimeout(350);
ok('single click expands answer chips',await p.locator('tr.det .ans').count()>0,0);

// 2. double click opens the drawer in edit mode
await p.locator('tr.row').nth(0).dblclick();await p.waitForTimeout(300);
ok('double click opens edit mode',await p.locator('#ed_n').count()===1);
ok('answers are editable',await p.locator('#oed .oline').count()>0);

// 3. editing marks rows pending
await p.fill('#ed_n','SMOKE TEST WORDING');
await p.click('button:has-text("Save changes")');await p.waitForTimeout(300);
ok('edit saved',(await p.locator('#drawer h3').first().textContent()).includes('SMOKE TEST'));

// 4. tickboxes toggle both ways
const on=()=>p.locator('.tick2:not(.off)').count();
const before=await on();await p.locator('.tick2:not(.off)').first().click();await p.waitForTimeout(200);
const after=await on();await p.locator('.tick2.off').first().click();await p.waitForTimeout(200);
ok('untick removes a document',after===before-1,after);
ok('tick adds a document',await on()===before,await on());
await p.click('#drawer .x');

// 5. section + with duplicate guard
await p.locator('.addbtn').first().click();await p.waitForTimeout(200);
ok('section + opens the add form',await p.locator('#nc_a input').count()===16);
await p.fill('#nc_n','Ladders, walkways, safety rails, stairs with self-closing safety gate');await p.waitForTimeout(300);
ok('look-alike warning appears while typing',await p.locator('#nc_dup .warn').count()===1);
await p.locator('#nc_a input').first().check();
await p.click('button:has-text("Add check")');await p.waitForTimeout(250);
ok('duplicate is blocked with a confirm',(await p.locator('#mbox h3').textContent()).includes('already exist'));
await p.click('button:has-text("Add mine anyway")');await p.waitForTimeout(400);
ok('forced add opens the new check',await p.locator('#dr.open').count()===1);
await p.click('#drawer .x');

// 6. export: any mix of units and levels
await p.click('nav button[data-v=matrix]');
await p.click('button:has-text("Export PDF")');await p.waitForTimeout(250);
ok('export dialog lists 4 units + 7 levels + answers',await p.locator('#mbox input[type=checkbox]').count()===12);
for(const l of ['SL0 Rigup','SL0 RigDown','SL0 Incoming'])await p.locator(`label:has-text("${l}") input`).first().uncheck();
await p.locator('label:has-text("SL1") input').first().check();
for(const u of ['CPF-573','CPF-870'])await p.locator(`#mbox label:has-text("${u}") input`).first().uncheck();
await p.waitForTimeout(150);
const dl=p.waitForEvent('download',{timeout:20000});await p.click('#expbtn');const d=await dl;
ok('PDF filename names the selection',d.suggestedFilename()==='CPF 2 units SL0 Outgoing SL1 checklist.pdf',d.suggestedFilename());

// 7. no page-level horizontal scroll on a phone
await p.setViewportSize({width:390,height:844});await p.waitForTimeout(300);
ok('no horizontal scroll at 390px',await p.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth+2));
ok('no uncaught page errors',errs.length===0,errs.join(' | '));
await b.close();
console.log(fails?`\n${fails} failed`:'\nall passed');
process.exit(fails?1:0);
