# CPF Master Checklist

A bird's-eye view of which maintenance checks belong to which CPF unit at which
service level — replacing the master checklist spreadsheet TLM maintains today.

**This is a demo.** State is in memory and resets on refresh. See
[HANDOVER.md](HANDOVER.md) for what is real and what is next.

## Run it

```bash
node server.js        # then open http://localhost:3000
```

Or `python -m http.server 3000`, or double-click `start.bat` (Windows) /
`./start.sh` (Mac, Linux). Nothing to install — the PDF library is bundled.
Change the port with `PORT=8080 node server.js`.

## Using it

- **Single click** a check in the matrix to see its answers.
- **Double click** to open the full detail panel in edit mode.
- **+ on a section heading** adds a check there, warning about look-alikes first.
- **Where it's used**: click any box to tick or untick a document.
- **Export PDF**: any mix of units and service levels, one document per page.

Unit filter modes answer different questions: *any* gives a unit's checklist,
*all* what units share, *only* what is unique to a unit, *missing* what a unit
lacks that the others have.

## Repo

| Path | |
|---|---|
| `index.html`, `styles.css`, `app.js` | the app |
| `data.js` | generated — 604 checks from the InTouch ACP rev 18 export |
| `tools/extract.py` | rebuilds `data.js` from the workbook |
| `tests/smoke.mjs` | `npm i playwright && node tests/smoke.mjs` |

Read [CLAUDE.md](CLAUDE.md) before changing anything, and
[ARCHITECTURE.md](ARCHITECTURE.md) for the data model and the target system.
